<!DOCTYPE html>
<html>
<head>
	<title>RemoteOS.com/profile.php</title>
</head>
<body>
	<?php 
		session_start();
		echo "<h3>Username: ".$_SESSION['username']."</h3><br>";
		echo "<h3>Name: ".$_SESSION['name']."</h3><br>";
		echo "<h3>Email: ".$_SESSION['email']."</h3><br>";
	 ?>
</body>
</html>